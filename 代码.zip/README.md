# MSPC-AnomalyNCD

**A Multi-Scale Mask-Guided Prototype Learning Method for Novel Defect Class Discovery in Industrial Visual Inspection**

本项目面向工业视觉检测中的**异常新类别发现（Novel Defect Class Discovery）**任务。在仅有外部已知缺陷类别标注、目标工业数据中的异常类别不提供人工标签的条件下，模型对异常区域进行表征学习、类别组织与图像级预测。

代码以 AnomalyNCD 为基础，进一步实现了以下核心模块：

- **MS-MGViT**：多尺度掩码引导视觉 Transformer，通过掩码引导注意力、多层级特征提取和跨尺度注意力融合增强局部异常区域表征。
- **PMB**：动量原型记忆库，使用已知类真实标签和未知类高置信伪标签维护稳定类别原型。
- **CARM**：置信感知区域合并，在推理阶段综合区域面积、分类置信度、异常分数、预测间隔、多头一致性和多头 KL 一致性，生成图像级预测。

---

## 1. 方法流程

```text
Target images + anomaly maps
            │
            ▼
   MEBin binarization and cropping
            │
            ▼
      Region crops + masks
            │
            ▼
          MS-MGViT
     ┌──────┴─────────┐
     ▼                ▼
Projector features   Multi-head logits
     │                │
     ▼                ├── Auxiliary consistency learning
    PMB               │
     └──────┬─────────┘
            ▼
    Region-level predictions
            │
            ▼
           CARM
            │
            ▼
     Image-level predictions
```

训练数据由两部分组成：

1. **已知类有标签数据**：默认使用 AeBAD-S 裁剪得到的缺陷区域及其真实标签；
2. **目标域无标签数据**：使用 MVTec AD 或 MTD 的异常图和异常图分数，经 MEBin 生成区域裁剪和二值掩码。

评估阶段仅在目标域未知异常类别上计算 **NMI、ARI 和 F1**，其中 F1 在 Hungarian matching 后计算。

---

## 2. 项目结构

```text
MSPC-AnomalyNCD/
├── assets/
│   └── pipeline.png                 # 项目中保留的流程示意图
├── configs/
│   └── AnomalyNCD.yaml              # 模型、训练、损失和推理配置
├── datasets/
│   ├── aebad_preprocess.py          # AeBAD-S 已知类数据裁剪
│   ├── mtd_preprocess.py            # MTD 数据格式转换
│   ├── data_utils.py                # 数据集划分与采样
│   ├── dataset.py                   # PyTorch Dataset
│   └── transform.py                 # 图像与掩码增强
├── examples/
│   └── anomalyncd_main.py           # 训练与测试主入口
├── models/
│   ├── AnomalyNCD.py                # 完整训练、评估和 CARM 流程
│   ├── loss/
│   │   ├── _contrastive_loss.py
│   │   ├── _distill_loss.py
│   │   └── _prototype_memory_bank.py # PMB
│   └── modules/
│       ├── _MEBin.py                # 异常图二值化与区域裁剪
│       ├── _MGViT.py                # MS-MGViT
│       ├── _classifier.py           # 多头分类器与投影头
│       └── load_backbone.py         # DINO ViT 权重加载
├── scripts/
│   ├── anomalyncd.sh                # 训练脚本
│   ├── anomalyncd_test.sh           # 测试脚本
│   ├── plot_attention_compare.py    # 注意力可视化
│   ├── plot_carm_case.py            # CARM 案例可视化
│   ├── plot_tsne_compare.py         # t-SNE 特征可视化
│   └── profile_efficiency.py        # 参数量、时延、显存与 FLOPs 分析
├── utils/
│   ├── cluster_and_log_utils.py      # 聚类评价指标
│   └── general_utils.py             # 配置、日志和实验目录
├── LICENSE
└── README.md
```

---

## 3. 环境配置

### 3.1 推荐环境

- Ubuntu 20.04/22.04 或 Windows 11 + WSL2
- Python 3.8
- CUDA 11.8
- PyTorch 2.0.0
- torchvision 0.15.1
- 单张 NVIDIA GPU，推荐显存不低于 12 GB

默认配置的 `batch_size=48` 对显存要求较高。显存不足时可在 `configs/AnomalyNCD.yaml` 中减小批量大小。

### 3.2 创建环境

```bash
conda create -n mspc_anomalyncd python=3.8 -y
conda activate mspc_anomalyncd
```

安装 PyTorch：

```bash
pip install torch==2.0.0 torchvision==0.15.1 \
  --index-url https://download.pytorch.org/whl/cu118
```

安装其余依赖：

```bash
pip install numpy scipy scikit-learn opencv-python pillow \
  pyyaml loguru tqdm matplotlib
```

检查 CUDA：

```bash
python -c "import torch; print(torch.__version__); print(torch.cuda.is_available())"
```

> 首次运行时，`models/modules/load_backbone.py` 会自动下载 DINO ViT-B/8 或 ViT-B/16 预训练权重，请确保运行环境能够访问下载地址。后续运行将使用 PyTorch 缓存中的权重。

---

## 4. 数据准备

建议将数据统一放在项目根目录下的 `data/` 中。

### 4.1 AeBAD-S：已知类有标签数据

原始 AeBAD 数据目录示例：

```text
data/AeBAD/
└── AeBAD_S/
    ├── test/
    │   ├── class_1/
    │   ├── class_2/
    │   └── ...
    └── ground_truth/
        ├── class_1/
        ├── class_2/
        └── ...
```

在 `datasets/aebad_preprocess.py` 底部确认以下路径：

```python
origin_path = 'data/AeBAD'
save_crop_path = 'data/AeBAD_crop'
```

运行：

```bash
python datasets/aebad_preprocess.py
```

预处理结果应满足：

```text
data/AeBAD_crop/
├── images/
│   ├── known_class_1/*.png
│   ├── known_class_2/*.png
│   └── ...
└── masks/
    ├── known_class_1/*.png
    ├── known_class_2/*.png
    └── ...
```

`images/` 与 `masks/` 下的类别目录和文件顺序必须一一对应。

### 4.2 MVTec AD：目标域无标签数据

原始图像目录应符合 MVTec AD 官方结构：

```text
data/mvtec_anomaly_detection/
├── bottle/
│   └── test/
│       ├── broken_large/*.png
│       ├── broken_small/*.png
│       └── contamination/*.png
├── cable/
└── ...
```

异常图目录示例：

```text
data/mvtec_musc_anomaly_map/
├── bottle/
│   ├── broken_large/*
│   ├── broken_small/*
│   └── contamination/*
├── cable/
└── ...
```

对于每个异常类型，异常图与原图必须具有相同数量，并在按文件名排序后保持一一对应。代码会自动忽略名为 `combined` 的异常类型目录。

运行时，MEBin 将生成：

```text
data/mvtec_musc/                # 二值化异常图
data/mvtec_musc_crop/
├── bottle/
│   ├── images/<defect_type>/*.png
│   └── masks/<defect_type>/*.png
├── cable/
└── scores_json/
    ├── bottle.json
    ├── cable.json
    └── ...
```

### 4.3 MTD：目标域无标签数据

首先在 `datasets/mtd_preprocess.py` 中设置：

```python
org_mtd_dir = 'data/Magnetic-tile-defect-datasets'
train_txt = 'data/Magnetic-tile-defect-datasets/mtd_train_filenames.txt'
new_mtd_dir = 'data/mtd_anomaly_detection'
```

运行格式转换：

```bash
python datasets/mtd_preprocess.py
```

转换后测试目录为：

```text
data/mtd_anomaly_detection/
└── test/
    ├── Blowhole/*.jpg
    ├── Break/*.jpg
    ├── Crack/*.jpg
    ├── Fray/*.jpg
    ├── Uneven/*.jpg
    └── MT_Free/*.jpg
```

异常图目录示例：

```text
data/mtd_musc_anomaly_map/
└── MTD/
    ├── Blowhole/*
    ├── Break/*
    ├── Crack/*
    ├── Fray/*
    └── Uneven/*
```

训练脚本中 MTD 的 `dataset_path` 应指向：

```text
data/mtd_anomaly_detection/test
```

---

## 5. 配置说明

主要配置文件为 `configs/AnomalyNCD.yaml`。

### 5.1 MEBin

```yaml
binarization:
  sample_rate: 4
  min_interval_len: 4
  erode: True
```

- `sample_rate`：异常分数采样率；
- `min_interval_len`：主区间的最小长度；
- `erode`：是否对二值掩码执行腐蚀处理。

### 5.2 MS-MGViT

```yaml
models:
  grad_from_block: 11
  pretrained_backbone: dino_vitb8
  mask_layers: 9
  ms_layers: [3, 6, 9, 12]
  feature_fusion: cross_attention
  aux_layers: [6, 9]
  n_views: 2
  n_head: 4
```

- `grad_from_block`：从指定 Transformer block 开始解冻；代码中的 block 编号从 0 开始；
- `pretrained_backbone`：支持 `dino_vitb8` 和 `dino_vitb16`；
- `mask_layers`：从网络后部开始启用掩码引导注意力的层数；
- `ms_layers`：用于多尺度特征提取的层；
- `feature_fusion`：多尺度融合方式，默认使用 `cross_attention`；
- `aux_layers`：辅助一致性分类头对应的层；
- `n_views`：对比学习视图数，当前训练流程按 2 个视图实现；
- `n_head`：多头分类器数量。

### 5.3 训练参数

```yaml
training:
  batch_size: 48
  num_workers: 8
  lr: 0.003
  gamma: 0.1
  momentum: 0.9
  weight_decay: 0.00005
  epochs: 50
```

优化器为 SGD，学习率采用 Cosine Annealing 调度。

### 5.4 PMB 与一致性学习

```yaml
loss:
  consistency_weight: 0.8
  consistency_distill_temp: 1.0
  consistency_scope: unlabeled_high_conf
  consistency_select_mode: top_ratio
  consistency_top_ratio: 0.3
  consistency_warmup_epochs: 5

  proto_weight: 0.1
  proto_momentum: 0.95
  proto_temperature: 0.07
  proto_conf_threshold: 0.5
```

- `proto_weight`：原型对比损失权重；设为 `0` 可关闭 PMB 损失项；
- `proto_momentum`：类别原型 EMA 更新动量；
- `proto_temperature`：原型对比学习温度；
- `proto_conf_threshold`：无标签样本参与未知类原型更新的置信度阈值；
- `consistency_weight`：多尺度辅助头一致性损失权重；
- `consistency_top_ratio`：在高置信未知样本中选取的比例。

对于 MTD，可根据实验设置将 `proto_conf_threshold` 设为 `0.0`，使全部无标签样本参与未知类原型更新；MVTec AD 建议保留置信度筛选。

### 5.5 CARM

```yaml
inference:
  use_confidence_area_merge: True
  confidence_area_alpha: 1.0
  confidence_area_beta: 1.0
  confidence_area_eps: 0.000001
  carm_conf_temp: 1.0
  carm_area_gamma: 0.5
  carm_use_density: True
  carm_normalize_signals: True
  carm_use_head_agreement: True
  carm_agreement_weight: 0.5
  carm_use_margin_signal: True
  carm_margin_mode: top2_entropy
  carm_margin_weight: 0.35
  carm_use_head_kl: True
  carm_head_kl_weight: 0.25
```

将 `use_confidence_area_merge` 设为 `False` 可退化为基于区域面积的合并策略。

---

## 6. 训练

### 6.1 单个 MVTec AD 类别

在项目根目录执行：

```bash
CUDA_VISIBLE_DEVICES=0 python examples/anomalyncd_main.py \
  --runner_name mvtec_musc_crop \
  --dataset mvtec \
  --category bottle \
  --dataset_path data/mvtec_anomaly_detection \
  --anomaly_map_path data/mvtec_musc_anomaly_map \
  --binary_data_path data/mvtec_musc \
  --crop_data_path data/mvtec_musc_crop \
  --base_data_path data/AeBAD_crop \
  --config configs/AnomalyNCD.yaml
```

### 6.2 全部 MVTec AD 类别

先检查 `scripts/anomalyncd.sh` 中的数据路径和 GPU 编号，然后执行：

```bash
bash scripts/anomalyncd.sh
```

脚本默认依次训练 15 个 MVTec AD 类别。

### 6.3 MTD

取消 `scripts/anomalyncd.sh` 中 MTD 部分的注释，或直接运行：

```bash
CUDA_VISIBLE_DEVICES=0 python examples/anomalyncd_main.py \
  --runner_name mtd_musc_crop \
  --dataset mtd \
  --category MTD \
  --dataset_path data/mtd_anomaly_detection/test \
  --anomaly_map_path data/mtd_musc_anomaly_map \
  --binary_data_path data/mtd_musc \
  --crop_data_path data/mtd_musc_crop \
  --base_data_path data/AeBAD_crop \
  --config configs/AnomalyNCD.yaml
```

### 6.4 训练流程说明

每次调用主程序时会依次执行：

1. 删除当前类别已有的二值图和裁剪结果；
2. 读取异常图并执行 MEBin；
3. 生成区域图像、区域掩码和 `scores_json`；
4. 构建已知类与未知类混合训练集；
5. 加载 DINO 预训练权重；
6. 训练 MS-MGViT、分类头、辅助头和 PMB；
7. 在最后一个 epoch 计算区域级与图像级指标；
8. 保存模型和实验日志。

---

## 7. 测试

`--checkpoint_path` 需要传入包含 `checkpoints/model.pt` 的实验运行目录，而不是直接传入 `model.pt`。

```bash
CUDA_VISIBLE_DEVICES=0 python examples/anomalyncd_main.py \
  --runner_name mvtec_musc_crop \
  --dataset mvtec \
  --category bottle \
  --dataset_path data/mvtec_anomaly_detection \
  --anomaly_map_path data/mvtec_musc_anomaly_map \
  --binary_data_path data/mvtec_musc \
  --crop_data_path data/mvtec_musc_crop \
  --base_data_path data/AeBAD_crop \
  --only_test True \
  --checkpoint_path outputs/mvtec_musc_crop/log/<experiment_directory>
```

也可以修改并执行：

```bash
bash scripts/anomalyncd_test.sh
```

> 当前源码在测试模式下仍会先执行 `binarization()`，因此测试时仍需提供原始图像和异常图，并会重建当前类别的裁剪目录。

---

## 8. 输出文件

默认输出结构：

```text
outputs/
└── <runner_name>/
    ├── metrics.csv
    └── log/
        └── <exp_name>_<category>_(timestamp)/
            ├── log.txt
            └── checkpoints/
                └── model.pt
```

其中：

- `log.txt`：训练损失、辅助一致性统计以及 NMI、ARI、F1；
- `model.pt`：模型参数、优化器状态、epoch、各分类头聚类损失及模型配置；
- `metrics.csv`：各类别最终图像级 NMI、ARI 和 F1。

当多个类别使用相同 `runner_name` 时，结果将追加到同一个 `metrics.csv`。

---

## 9. 可视化与效率分析

### 9.1 t-SNE 特征可视化

查看完整参数：

```bash
python scripts/plot_tsne_compare.py --help
```

### 9.2 注意力对比

```bash
python scripts/plot_attention_compare.py \
  --category bottle \
  --base_data_path data/AeBAD_crop \
  --crop_data_path data/mvtec_musc_crop \
  --checkpoint outputs/mvtec_musc_crop/log/<experiment_directory> \
  --output_dir outputs/attention_compare
```

可通过 `--baseline_checkpoint` 额外提供基线模型，绘制 DINO、基线 MGViT 与 MS-MGViT 的注意力对比。

### 9.3 CARM 案例可视化

```bash
python scripts/plot_carm_case.py \
  --category bottle \
  --base_data_path data/AeBAD_crop \
  --crop_data_path data/mvtec_musc_crop \
  --checkpoint outputs/mvtec_musc_crop/log/<experiment_directory> \
  --dataset mvtec \
  --output_dir outputs/carm_cases
```

### 9.4 工程效率分析

```bash
python scripts/profile_efficiency.py \
  --config configs/AnomalyNCD.yaml \
  --batch-size 1 \
  --warmup 20 \
  --iters 100 \
  --output outputs/efficiency_profile.csv
```

该脚本比较基础模型与完整方法的参数量、推理时间、峰值显存和 FLOPs。若运行环境无法统计 FLOPs，可加入 `--skip-flops`。

---

## 10. 论文报告结果

| Dataset | NMI | ARI | F1 |
|---|---:|---:|---:|
| MVTec AD | 0.634 | 0.551 | 0.737 |
| MTD | 0.270 | 0.230 | 0.501 |

结果会受到随机种子、PyTorch/CUDA 版本、异常图质量、数据裁剪结果及类别顺序影响。默认随机种子为 `215`。

---

## 11. 常见问题

### 11.1 显存不足

在配置文件中减小：

```yaml
training:
  batch_size: 16
  num_workers: 4
```

如果仍然不足，可改用 `dino_vitb16`，但需要重新验证实验结果。

### 11.2 图像和异常图不匹配

代码分别对原图和异常图文件名排序后按索引配对。请确保：

- 两个目录中的文件数量一致；
- 排序后的文件顺序一致；
- 每个异常类型目录名称一致；
- 不要混入隐藏文件或无关文件。

### 11.3 找不到 checkpoint

测试参数应指向实验目录：

```text
outputs/<runner_name>/log/<experiment_directory>
```

程序会自动拼接：

```text
checkpoints/model.pt
```

### 11.4 DINO 权重下载失败

可手动下载对应权重，并放入 PyTorch Hub 缓存目录。默认骨干 `dino_vitb8` 对应 DINO ViT-Base/8 预训练权重。

### 11.5 Windows 原生路径问题

部分源码使用 `/` 解析路径，建议在 Linux 或 WSL2 环境中运行，以避免 Windows 反斜杠导致类别名或文件名解析异常。

### 11.6 CARM 出现 anomaly-score fallback 警告

日志若出现：

```text
[CARM] ano_score fallback triggered ...
```

说明区域裁剪文件名与 `scores_json/<category>.json` 未完全对齐。请检查是否在生成裁剪后手动改名、移动文件或混用了不同版本的预处理结果。

---

## 12. 复现实验建议

为获得可比较结果，建议：

1. 固定随机种子和数据目录；
2. 每次实验保留完整 YAML 配置；
3. 不在 MEBin 处理后手动修改裁剪文件名；
4. MVTec AD 各类别使用一致的训练设置；
5. 分别保存 MVTec AD 与 MTD 的配置，尤其是 `proto_conf_threshold`；
6. 汇总 `metrics.csv` 前确认每个类别只保留一次有效实验结果。

---

## 13. Acknowledgements

本项目使用或参考了以下工作中的实现思想：

- AnomalyNCD
- DINO
- SimGCD
- UNO

分类器、聚类评价及部分训练工具基于相关开源实现进行了修改。感谢这些工作的作者。

---

## 14. License

本项目沿用仓库中的 MIT License。使用和再发布代码时，请同时保留原始许可证及相应版权声明。

## 15. Citation

论文正式发表后，请使用论文页面提供的 BibTeX 信息引用本项目。
